//
//  TargetToggleMouseScope.h
//  Enjoy
//
//  Created by Yifeng Huang on 7/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Target.h"

@interface TargetToggleMouseScope : Target

+(TargetToggleMouseScope*) unstringifyImpl: (NSArray*) comps;

@end
