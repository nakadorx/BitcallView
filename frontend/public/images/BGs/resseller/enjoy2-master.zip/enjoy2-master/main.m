//
//  main.m
//  Enjoy
//
//  Created by Sam McCall on 4/05/09.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
